# backend/main.py
import os
from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import io
import logging

# Azure Cognitive Services SDKs
from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.credentials import AzureKeyCredential
from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from azure.cognitiveservices.vision.computervision.models import OperationStatusCodes
import azure.cognitiveservices.speech as speechsdk
import time

# NEW IMPORT for ComputerVisionClient credentials
from msrest.authentication import CognitiveServicesCredentials

# --- Configuration (Replace with your actual Azure Keys and Endpoints) ---
# It's highly recommended to use Azure Key Vault and Managed Identities in production.
# For local development, you can set these as environment variables or directly here.

# Azure Language Service (for Text Analytics and Language Detection)
AZURE_LANGUAGE_KEY = os.getenv("AZURE_LANGUAGE_KEY", "3ze8fA7ksKOWUaawwqbLu1MHC2Gm79Q6XhRDKeZ1NzJyyBfTjJZXJQQJ99BGACYeBjFXJ3w3AAAaACOGwbHB")
AZURE_LANGUAGE_ENDPOINT = os.getenv("AZURE_LANGUAGE_ENDPOINT", "https://language-analysisrg.cognitiveservices.azure.com/")

# Azure Computer Vision Service (for OCR)
AZURE_VISION_KEY = os.getenv("AZURE_VISION_KEY", "ElzJkVg5M4SFKesp7eO7HxotIqhHhASFueRlQiQDFnhmDk9V39AOJQQJ99BGACYeBjFXJ3w3AAAFACOGKRAx")
AZURE_VISION_ENDPOINT = os.getenv("AZURE_VISION_ENDPOINT", "https://ocr-cvision.cognitiveservices.azure.com/")

# Azure Speech Service (for Text-to-Speech and Speech-to-Text)
AZURE_SPEECH_KEY = os.getenv("AZURE_SPEECH_KEY", "BYOJr9YYkq4Scnt5X6tmQaHHlB4m4IaUDvirLGjLrrJlLuCFkl13JQQJ99BGACYeBjFXJ3w3AAAYACOGQcGy")
AZURE_SPEECH_REGION = os.getenv("AZURE_SPEECH_REGION", "eastus") # e.g., "eastus", "westus2"

# --- Initialize FastAPI App ---
app = FastAPI(
    title="Azure AI NLP Project Backend",
    description="FastAPI application integrating Azure Cognitive Services for NLP tasks.",
    version="1.0.0"
)

# --- CORS Middleware ---
# Allows frontend to make requests to this backend.
# In a production environment, restrict origins to your frontend's domain.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)

# --- Logging Configuration ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- Azure Service Clients Initialization ---
try:
    # Text Analytics Client
    text_analytics_client = TextAnalyticsClient(
        endpoint=AZURE_LANGUAGE_ENDPOINT,
        credential=AzureKeyCredential(AZURE_LANGUAGE_KEY)
    )
    logger.info("Azure Text Analytics client initialized.")
except Exception as e:
    logger.error(f"Failed to initialize Azure Text Analytics client: {e}")
    text_analytics_client = None # Set to None if initialization fails

try:
    # Computer Vision Client
    computervision_client = ComputerVisionClient(
        AZURE_VISION_ENDPOINT,
        CognitiveServicesCredentials(AZURE_VISION_KEY) # Use CognitiveServicesCredentials
    )
    logger.info("Azure Computer Vision client initialized.")
except Exception as e:
    logger.error(f"Failed to initialize Azure Computer Vision client: {e}")
    computervision_client = None # Set to None if initialization fails

# Speech SDK configuration (initialized per request for specific tasks)
speech_config = speechsdk.SpeechConfig(
    subscription=AZURE_SPEECH_KEY,
    region=AZURE_SPEECH_REGION
)
logger.info("Azure SpeechConfig initialized.")


# --- Pydantic Models for Request Bodies ---
class TextInput(BaseModel):
    text: str

# Removed SpeechToTextInput model as Speech-to-Text is being removed
# class SpeechToTextInput(BaseModel):
#     language: str = "en-US" # Default language for transcription

class TextToSpeechInput(BaseModel):
    text: str
    voice_name: str = "en-US-JennyNeural" # Default voice
    language: str = "en-US" # Default language for synthesis


# --- API Endpoints ---

@app.post("/analyze/text")
async def analyze_text(input: TextInput):
    """
    Performs Opinion Mining (Sentiment Analysis with aspect-based sentiment)
    and Key Phrase Extraction on the provided text.
    """
    if not text_analytics_client:
        raise HTTPException(status_code=500, detail="Text Analytics service not available.")

    try:
        documents = [input.text]

        response = text_analytics_client.analyze_sentiment(
            documents,
            show_opinion_mining=True
        )
        sentiment_result = []
        for doc in response:
            if not doc.is_error:
                opinions = []
                for sentence in doc.sentences:
                    for opinion in sentence.mined_opinions:
                        opinions.append({
                            "target": opinion.target.text,
                            "target_sentiment": str(opinion.target.sentiment),
                            "assessments": [{"text": a.text, "sentiment": str(a.sentiment)} for a in opinion.assessments]
                        })
                sentiment_result.append({
                    "document_sentiment": str(doc.sentiment),
                    "confidence_scores": {
                        "positive": doc.confidence_scores.positive,
                        "neutral": doc.confidence_scores.neutral,
                        "negative": doc.confidence_scores.negative
                    },
                    "opinions": opinions
                })
            else:
                sentiment_result.append({"error": doc.error.message})

        # Key Phrase Extraction
        key_phrases_response = text_analytics_client.extract_key_phrases(documents)
        key_phrases_result = []
        for doc in key_phrases_response:
            if not doc.is_error:
                key_phrases_result.append(doc.key_phrases)
            else:
                key_phrases_result.append({"error": doc.error.message})

        return JSONResponse(content={
            "sentiment_analysis": sentiment_result[0] if sentiment_result else {},
            "key_phrases": key_phrases_result[0] if key_phrases_result else []
        })
    except Exception as e:
        logger.error(f"Error analyzing text: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to analyze text: {e}")

@app.post("/analyze/language")
async def detect_language(input: TextInput):
    """
    Detects the language of the provided text.
    """
    if not text_analytics_client:
        raise HTTPException(status_code=500, detail="Text Analytics service not available.")

    try:
        documents = [input.text]
        response = text_analytics_client.detect_language(documents)
        language_result = []
        for doc in response:
            if not doc.is_error:
                language_result.append({
                    "language": doc.primary_language.name,
                    "iso6391_name": doc.primary_language.iso6391_name,
                    "confidence_score": doc.primary_language.confidence_score
                })
            else:
                language_result.append({"error": doc.error.message})

        return JSONResponse(content={"language_detection": language_result[0] if language_result else {}})
    except Exception as e:
        logger.error(f"Error detecting language: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to detect language: {e}")

@app.post("/ocr")
async def ocr_image(file: UploadFile = File(...)):
    """
    Performs Optical Character Recognition (OCR) on an uploaded image.
    """
    if not computervision_client:
        raise HTTPException(status_code=500, detail="Computer Vision service not available.")

    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="Invalid file type. Please upload an image.")

    try:
        # Read the image file into a stream
        image_stream = io.BytesIO(await file.read())

        # Call the Azure Computer Vision Read API
        read_response = computervision_client.read_in_stream(image_stream, raw=True)

        # Get the operation location (URL with an ID for the asynchronous operation)
        operation_location = read_response.headers["Operation-Location"]
        operation_id = operation_location.split("/")[-1]

        # Wait for the operation to complete
        while True:
            read_result = computervision_client.get_read_result(operation_id)
            if read_result.status not in [OperationStatusCodes.running, OperationStatusCodes.not_started]:
                break
            time.sleep(1)

        # Extract text
        extracted_text = []
        if read_result.status == OperationStatusCodes.succeeded:
            for text_result in read_result.analyze_result.read_results:
                for line in text_result.lines:
                    extracted_text.append(line.text)
        else:
            raise HTTPException(status_code=500, detail=f"OCR failed with status: {read_result.status}")

        return JSONResponse(content={"extracted_text": extracted_text})
    except Exception as e:
        logger.error(f"Error performing OCR: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to perform OCR: {e}")

@app.post("/speech/text-to-speech")
async def text_to_speech(input: TextToSpeechInput):
    """
    Converts text to speech and returns an audio file.
    """
    try:
        # Set the voice for synthesis
        speech_config.speech_synthesis_voice_name = input.voice_name
        # Set the output format to WAV for broader compatibility
        speech_config.set_speech_synthesis_output_format(speechsdk.SpeechSynthesisOutputFormat.Riff16Khz16BitMonoPcm)

        synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=None) # audio_config=None means output to memory
        
        result = synthesizer.speak_text_async(input.text).get()

        if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
            audio_data = result.audio_data
            # Return audio data as a StreamingResponse
            return StreamingResponse(io.BytesIO(audio_data), media_type="audio/wav")
        elif result.reason == speechsdk.ResultReason.Canceled:
            cancellation_details = result.cancellation_details
            error_message = f"Speech synthesis canceled: {cancellation_details.reason}. Error details: {cancellation_details.error_details}"
            logger.error(error_message)
            raise HTTPException(status_code=500, detail=error_message)
    except Exception as e:
        logger.error(f"Error converting text to speech: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to convert text to speech: {e}")


# Removed Speech-to-Text endpoint
# @app.post("/speech/speech-to-text")
# async def speech_to_text(file: UploadFile = File(...), language: str = Form("en-US")):
#     """
#     Transcribes an uploaded audio file to text.
#     Supports WAV format for simplicity in this example.
#     """
#     if not file.content_type.startswith("audio/"):
#         raise HTTPException(status_code=400, detail="Invalid file type. Please upload an audio file.")
    
#     # Ensure the audio format is compatible with Azure Speech Service.
#     # For simplicity, this example assumes WAV.
#     # In a real app, you might need to convert formats or handle more types.
#     if not (file.content_type == "audio/wav" or file.filename.lower().endswith(".wav")):
#         raise HTTPException(status_code=400, detail="Only WAV audio files are supported for now.")

#     try:
#         audio_data = await file.read()
        
#         # CORRECTED: Use PushAudioInputStream for feeding in-memory audio data to the recognizer
#         push_stream = speechsdk.audio.PushAudioInputStream()
#         push_stream.write(audio_data)
#         push_stream.close() # Important: Close the stream after writing all data

#         audio_config = speechsdk.audio.AudioConfig(stream=push_stream) # Use the push_stream

#         speech_config.speech_recognition_language = language
        
#         recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)

#         # Perform continuous recognition for longer audio, or single_shot for short audio.
#         # For simplicity, we'll use single_shot recognition here.
#         # For larger files, consider batch transcription or continuous recognition with event handling.
#         result = recognizer.recognize_once_async().get()

#         if result.reason == speechsdk.ResultReason.RecognizedSpeech:
#             return JSONResponse(content={"transcribed_text": result.text})
#         elif result.reason == speechsdk.ResultReason.NoMatch:
#             return JSONResponse(content={"transcribed_text": "No speech could be recognized."})
#         elif result.reason == speechsdk.ResultReason.Canceled:
#             cancellation_details = result.cancellation_details
#             error_message = f"Speech recognition canceled: {cancellation_details.reason}. Error details: {cancellation_details.error_details}"
#             logger.error(error_message)
#             raise HTTPException(status_code=500, detail=error_message)
#     except Exception as e:
#         logger.error(f"Error transcribing speech: {e}")
#         raise HTTPException(status_code=500, detail=f"Failed to transcribe speech: {e}")

# --- Root Endpoint for Health Check ---
@app.get("/")
async def read_root():
    return {"message": "Azure AI NLP Backend is running!"}

# --- How to Run the Backend ---
# 1. Save this code as `main.py` inside a `backend` folder.
# 2. Create a `requirements.txt` file in the `backend` folder with the following content:
#    fastapi
#    uvicorn[standard]
#    python-multipart
#    azure-ai-textanalytics==5.3.0 # Use a compatible version
#    azure-cognitiveservices-vision-computervision==0.9.0 # Use a compatible version
#    azure-cognitiveservices-speech==1.38.0 # Use a compatible version
#    msrest # Add this new dependency
# 3. Install dependencies: `pip install -r requirements.txt`
# 4. Set your Azure environment variables (e.g., in your terminal before running):
#    export AZURE_LANGUAGE_KEY="YOUR_AZURE_LANGUAGE_KEY"
#    export AZURE_LANGUAGE_ENDPOINT="YOUR_AZURE_LANGUAGE_ENDPOINT"
#    export AZURE_VISION_KEY="YOUR_AZURE_VISION_KEY"
#    export AZURE_VISION_ENDPOINT="YOUR_AZURE_VISION_ENDPOINT"
#    export AZURE_SPEECH_KEY="YOUR_AZURE_SPEECH_KEY"
#    export AZURE_SPEECH_REGION="YOUR_AZURE_SPEECH_REGION"
# 5. Run the application: `uvicorn main:app --reload`
#    The API will be available at http://127.0.0.1:8000
#    You can access the interactive API documentation at http://127.0.0.1:8000/docs
